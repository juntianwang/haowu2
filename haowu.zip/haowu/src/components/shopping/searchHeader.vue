<template>
	<div class="wrap">
		<p>极客购</p>
		<div><span>🔍</span><span style="padding-left: 0.26rem;">轻松搜，全球购</span></div>
		<img src="../../../static/shopping/message.png"/>
	</div>
</template>

<script>
</script>

<style lang="scss" scoped="scoped">
	.wrap{
		display: flex;
		justify-content: space-around;
		align-items: center;
		padding: 0.4rem 0;
	}
	.wrap div{
		height: 0.6rem;
		width: 6.66rem;
		background: #eaebed;
		display: flex;
		justify-content: center;
		align-items: center;
		border-radius: 0.13rem;
		color: #909195;
	}
	.wrap img{
		width: 0.85rem;
	}
	.wrap p{
		font-size: 0.48rem;
		font-weight: bold;
		color: #191919;
	}
</style>