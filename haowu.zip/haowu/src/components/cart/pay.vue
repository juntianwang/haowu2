<template>
	<div class="pay">
		<router-view></router-view>
	</div>
</template>

<script>
</script>

<style lang="scss" scoped="" type="text/css">

</style>